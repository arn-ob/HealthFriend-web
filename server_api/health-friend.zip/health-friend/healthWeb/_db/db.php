<?php
    
    date_default_timezone_set("Asia/Dhaka");

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

    // header_remove('Access-Control-Allow-Origin');
    // header('Access-Control-Allow-Origin: *');
    
    // change the access info while in install at server
    
    $servername = "localhost";
    $username = "stupidar_ar";;
    $password = "uy+p]gkCmFam";
    $dbname = "stupidar_project"; 
    
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Connection Check
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>