<?php
    
    date_default_timezone_set("Asia/Dhaka");

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

    // header_remove('Access-Control-Allow-Origin');
    // header('Access-Control-Allow-Origin: *');
    
    // change the access info while in install at server
    
    $servername = "localhost";
    $username = "stupidar_ar";;
    $password = "uy+p]gkCmFam";
    $dbname = "stupidar_project"; 
    
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Connection Check
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql ="";
   

    $select = $_GET['s'];
    $data = $_GET['data'];
    $data_2 = $_GET['sp'];
    

    if($select === "ecg"){
        $sql = "INSERT INTO health_friend_ecg(data)  VALUES ('". $data ."')";
    }
    else if($select === "emg"){
        $sql = "INSERT INTO health_friend_emg(data)  VALUES ('". $data ."')";
    }
    else if($select === "gsr"){
        $sql = "INSERT INTO health_friend_gsr(data)  VALUES ('". $data ."')";
    }
    else if($select === "hrm"){
        $sql = "INSERT INTO health_friend_hrm(data1, data2)  VALUES ('". $data ."', '". $data_2 ."')";
    }
    else if($select === "temp"){
        $sql = "INSERT INTO health_friend_body_temp(data)  VALUES ('". $data ."')";
    }
    else{
        $select = "NaN";
    }
    
    if($select != "NaN"){
        if ($conn->query($sql) === TRUE) 
        {
           
            echo 200;
        }
        else {
            echo 400;
        }
    } else {
        echo 404;
    }
    
          
    // JSON Encoding to send 
	

  
    $conn->close();

?>